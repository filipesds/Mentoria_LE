package tests;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.concurrent.TimeUnit;

public class MentoriaTest {
    private WebDriver browser;

    @Before
    public void setUp(){
        System.setProperty("webdriver.chrome.driver","C:\\Users\\filipe.silva\\automação\\driver\\chromedriver.exe");
        browser = new ChromeDriver();
        browser.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        browser.manage().window().maximize();
        browser.get("http://automationpractice.com");

    }

    @Test
    public void testLogin() {
        browser.findElement(By.linkText("Sign in")).click();

        WebElement loginBox = browser.findElement(By.id("login_form"));
        loginBox.findElement(By.id("email")).sendKeys("novoemailteste@gmail.com");
        loginBox.findElement(By.id("passwd")).sendKeys("teste123");
        loginBox.findElement(By.id("SubmitLogin")).click();

        WebElement tshirtButton = browser.findElement(By.linkText("T-SHIRTS"));
        tshirtButton.click();

        String categoryName = browser.findElement(By.cssSelector("#center_column > h1 > span.cat-name")).getText();
        String validateCategoryName = categoryName.trim();
        Assert.assertEquals("T-SHIRTS",validateCategoryName);

        WebElement productDescription = browser.findElement(By.linkText("Faded Short Sleeve T-shirts"));
        String productNameList = productDescription.getText();
        productDescription.click();

        WebElement productDescriptionDetail = browser.findElement(By.cssSelector("#center_column > div > div > div.pb-center-column.col-xs-12.col-sm-4 > h1"));
        String productNameDetail = productDescriptionDetail.getText();
        Assert.assertEquals(productNameList, productNameDetail);

        WebElement addToCartButton = browser.findElement(By.id("add_to_cart"));
        addToCartButton.click();

        WebElement checkoutButton = browser.findElement(By.cssSelector("#layer_cart > div.clearfix > div.layer_cart_cart.col-xs-12.col-md-6 > div.button-container > a > span"));
        checkoutButton.click();

        WebElement summaryCheckoutButton = browser.findElement(By.cssSelector("#center_column > p.cart_navigation.clearfix > a.button.btn.btn-default.standard-checkout.button-medium"));
        summaryCheckoutButton.click();

        WebElement addressCheckoutButton = browser.findElement(By.cssSelector("#center_column > form > p > button"));
        addressCheckoutButton.click();

        WebElement agreeingCheckbox = browser.findElement(By.id("uniform-cgv"));
        agreeingCheckbox.click();

        WebElement shippingCheckoutButton = browser.findElement(By.name("processCarrier"));
        shippingCheckoutButton.click();

        WebElement paymentButton = browser.findElement(By.cssSelector("#HOOK_PAYMENT > div:nth-child(1) > div > p > a"));
        paymentButton.click();

        WebElement confirmOrderButton = browser.findElement(By.cssSelector("#cart_navigation > button"));
        confirmOrderButton.click();

        WebElement messageOrderCompleted = browser.findElement(By.cssSelector("[class='cheque-indent']"));
        String msgOrderCompleted = messageOrderCompleted.getText();
        Assert.assertEquals("Your order on My Store is complete.", msgOrderCompleted);

    }

       @After
      public void tearDown(){
          browser.quit();
      }
}
